<!DOCTYPE html>
<html lang="en">
<head>


<title>CSS Website Layout</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  margin: 0;
}

/* Style the header */
.header {
  background-color: #b4d8e8;
  padding: 20px;
  text-align: center;
}
footer {
            background-color: #b4d8e8;
            color: #fff;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}
/* Style the top navigation bar */
.topnav {
  overflow: hidden;
  background-color: #abbcd6;
}

/* Style the topnav links */
.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Create three equal columns that floats next to each other */
.column {
  float: left;
  width: 33.33%;
  padding: 15px;
}

/* Clear floats after the columns */
.row::after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width:600px) {
  .column {
    width: 100%;
  }
}
</style>
</head>
<body>

<div class="header">
  <h1>Deseases and Health</h1>
  <p>Prevention is better than Cure.</p>
</div>


<div class="topnav">
  <a href="http://127.0.0.1:5500/update.html">Desease</a>


  <a href="#">Health</a>
  <a href="#">Transmission</a>
  <a href="#">Prevention</a>

</div>



<div class="row">
  <div class="column">
    <h2>Dengue</h2>
    <img src="https://img.freepik.com/premium-vector/hand-drawn-dengue-mosquito-insecta_710141-381.jpg?w=740" alt="Dengue Image" style="width:60%">
    <p>Dengue (break-bone fever) is a viral infection that spreads from mosquitoes to people. It is more common in tropical and subtropical climates. Most people who get dengue won't have symptoms. But for those that do, the most common symptoms are high fever, headache, body aches, nausea and rash.</p>
  </div>

  <div class="column">
    <h2>Corona Virus</h2>
    <img src="https://phil.cdc.gov//PHIL_Images/23312/23312_lores.jpg" alt="Corona Virus Image" style="width:100%">
    <p>COVID-19 (coronavirus disease 2019) is a disease caused by a virus named SARS-CoV-2. It can be very contagious and spreads quickly. Over one million people have died from COVID-19 in the United States. COVID-19 most often causes respiratory symptoms that can feel much like a cold, the flu, or pneumonia.</p>
  </div>
  
  <div class="column">
    <h2>Doctors Advice</h2>
    <img src="https://static.vecteezy.com/system/resources/previews/002/972/128/original/doctor-advice-and-consultation-vector.jpg" alt="Doctors Advice Image" style="width:60%">
    <p>If you get dengue or covid, it's important to: rest. drink plenty of liquids. use acetaminophen (paracetamol) for pain. Call your doctor's office first to share your symptoms and ask if you should come in. Cough or sneeze into your elbow or use a tissue and throw it in the trash.</p>
  </div>
</div>

<footer>
    <p>&copy; 2023 Social Determinants of Health. All rights reserved.</p>
</footer>

</body>
</html>