
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Update Data</title>

  <style>

body {
    font-family: 'Arial', sans-serif;
    background-color: #f5f5f5;
    margin: 0;
    padding: 0;
}

h2 {
    color: #333;
}

form {
    max-width: 400px;
    margin: 20px auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

label {
    display: block;
    margin-bottom: 8px;
    color: #333;
}

input,
select {
    width: 100%;
    padding: 8px;
    margin-bottom: 16px;
    box-sizing: border-box;
}

button {
    background-color: #4285f4;
    color: #fff;
    padding: 10px 20px;
    border: none;
    cursor: pointer;
    font-size: 16px;
}

button:hover {
    background-color: #0066cc;
}

/* Style checkboxes */
label input[type="checkbox"] {
    margin-right: 10px;
}

/* Responsive styling for small screens */
@media (max-width: 600px) {
    form {
        width: 80%;
    }
}



  </style>

</head>
<body>

  <h2>Update Data</h2>

  <form id="updateForm">
    <label for="name">Name:</label>
    <input type="text" id="name" name="name">

    <label for="email">Email:</label>
    <input type="text" id="email" name="email">

    <label for="gender">Gender:</label>
    <select id="gender" name="gender">
      <option value="male">Male</option>
      <option value="female">Female</option>
    </select>

    <label for="desease">Desease:</label>
    <input type="text" id="desease" name="desease">

    <label>Treatment:</label>
    <label>
      <input type="checkbox" id="treatmentYes" name="treatment" value="yes">
      Yes
    </label>

    <label>
      <input type="checkbox" id="treatmentNo" name="treatment" value="no">
      No
    </label>


    <button type="button" onclick="updateData()">Update Data</button>
  </form>

  <script>
    function updateData() {
      // Get the values from the form
      var name = document.getElementById('name').value;
      var email = document.getElementById('email').value;
      var gender = document.getElementById('gender').value;
      var desease = document.getElementById('desease').value;
      var treatmentYes = document.getElementById('treatmentYes').checked;
      var treatmentNo = document.getElementById('treatmentNo').checked;

      // Determine the subscribe value based on checkbox state
      var treatment = treatmentYes ? 'Yes' : treatmentNo ? 'No' : '';

      // Retrieve existing data from localStorage or initialize an empty array
      var existingData = JSON.parse(localStorage.getItem('allData')) || [];

      // Create an object with the updated data
      var updatedData = { name: name, email: email, gender: gender, desease: desease, treatment: treatment };

      // Add the updated data to the array
      existingData.push(updatedData);

      // Convert the array to a JSON string and store it in localStorage
      localStorage.setItem('allData', JSON.stringify(existingData));

      alert('Data updated successfully!');
    }
  </script>

</body>
</html>