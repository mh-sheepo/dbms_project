<!DOCTYPE html>
<html lang="en">
<head>
<title>CSS Website Layout</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  margin: 0;
}

/* Style the header */
.header {
  background-color: #b4d8e8;
  padding: 20px;
  text-align: center;
}
footer {
            background-color: #b4d8e8;
            color: #fff;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}
/* Style the top navigation bar */
.topnav {
  overflow: hidden;
  background-color: #abbcd6;
}

/* Style the topnav links */
.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Create three equal columns that floats next to each other */
.column {
  float: left;
  width: 33.33%;
  padding: 15px;
}

/* Clear floats after the columns */
.row::after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width:600px) {
  .column {
    width: 100%;
  }
}
</style>
</head>
<body>

<div class="header">
  <h1>Food and Nutrition</h1>
  <p>Eat good, feel good – munching on nutritious vibes!</p>
</div>

<div class="topnav">
  <a href="http://localhost:3000/index.php">Food</a>
  <a href="#">Nutrition</a>
  <a href="#">Deficiencies</a>
  <a href="#">Conditions</a>
  <a href="#">Consideration</a>

</div>



<div class="row">
  <div class="column">
    <h2>Nutrition:</h2>
    <img src="https://s30386.pcdn.co/wp-content/uploads/2020/02/p1bm5844cb6oacnd1std183s12gt6.jpg.optimal.jpg" alt="Nutrition Image" style="width:50%">
    <p>Nutrition is the cornerstone of a healthy lifestyle. It involves providing the body with essential nutrients through a well-balanced diet. A diverse range of fruits, vegetables, whole grains, and lean proteins ensures the intake of vitamins, minerals, and other vital elements that support overall well-being and sustain bodily functions.</p>
  </div>

  <div class="column">
    <h2>Vitamins Benefits</h2>
    <img src="https://www.usatoday.com/gcdn/-mm-/d8d0774057d19139d16e6ede624d76e89947662d/c=1-0-1365-767/local/-/media/2022/01/19/USATODAY/usatsports/imageforentry8-etz.jpg?width=1364&height=767&fit=crop&format=pjpg&auto=webp" alt="Nutrition Image" style="width:90%">
    <p>Vitamins are micronutrients essential for various physiological processes. Each vitamin plays a unique role in promoting health, from boosting the immune system (vitamin C) to supporting bone health (vitamin D). Obtaining these nutrients through a diverse diet is crucial for maintaining energy, vitality, and the body's natural defense mechanisms.</p>
  </div>
  
  <div class="column">
    <h2>Sunlight Exposure</h2>
    <img src="https://bpb-us-e2.wpmucdn.com/sites.uci.edu/dist/1/4014/files/2021/08/Sunny-science.jpg" alt="Nutrition Image" style="width:70%">
    <p>Sunlight exposure is fundamental for synthesizing vitamin D, a crucial nutrient for bone health and immune function. Spending time outdoors and allowing the skin to absorb sunlight helps the body produce this vitamin naturally. Striking a balance between sun safety and enjoying outdoor activities contributes to overall health and well-being.</p>
  </div>
</div>

<footer>
    <p>&copy; 2023 Your Website Name. All rights reserved.</p>
</footer>

</body>
</html>